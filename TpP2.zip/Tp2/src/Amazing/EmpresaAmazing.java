package Amazing;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmpresaAmazing implements IEmpresa{
	private String Cuil;
	private Map<String, Transporte> flota;
	private Map<Integer, Pedido> pedidosRegistrados;
	
	public EmpresaAmazing(String cuil) {
        this.Cuil = cuil;
        this.flota = new HashMap<>();
        this.pedidosRegistrados = new HashMap<>();
    }


	public void registrarAutomovil(String patente, int volMax, int valorViaje, int maxPaq) {
		if(!this.flota.containsKey(patente)){
			TransporteComun transporte = new TransporteComun(patente,volMax,valorViaje, maxPaq);
			flota.put(patente, transporte);
		}
		else{
			throw new RuntimeException("Esta patente ya esta registrada.");
		}
	}
	
	public void registrarUtilitario(String patente, int volMax, int valorViaje, int valorExtra) {
		if(!this.flota.containsKey(patente)){
			TransporteUtilitario transporte = new TransporteUtilitario(patente ,volMax,valorViaje, valorExtra);
			flota.put(patente, transporte);
			}
		else{
			throw new RuntimeException("Esta patente ya esta registrada.");
		}
	}
	
	 public void registrarCamion(String patente, int volMax, int valorViaje, int adicXPaq) {
			if(!this.flota.containsKey(patente)){
				TransporteCamion transporte = new TransporteCamion(patente,volMax,valorViaje, adicXPaq);
				flota.put(patente, transporte);
		}
		else{
			throw new RuntimeException("Esta patente ya esta registrada.");
		}
	}
	 
	public int registrarPedido(String cliente, String direccion, int dni) {		
		Cliente clienteCreado = new Cliente(cliente,direccion, dni);
		
		Pedido nuevoPedido = new Pedido(clienteCreado);
		this.pedidosRegistrados.put(nuevoPedido.getNumeroDePedido(), nuevoPedido);
		return 	nuevoPedido.getNumeroDePedido();
	}
		
	public int agregarPaquete(int codPedido, int volumen, int precio, int porcentaje, int adicional) {
 
		Pedido pedido = obtenerPedido(codPedido);
		return pedido.agregarPaqueteEsp(codPedido, volumen, precio, porcentaje, adicional);
	}
	
	public int agregarPaquete(int codPedido, int volumen, int precio, int costoEnvio) {
		Pedido pedido = obtenerPedido(codPedido);
		return pedido.agregarPaqueteOrd(codPedido, volumen, precio, costoEnvio);
		}
			
		//auxiliares de agregarPaquete 

	public Pedido obtenerPedido(int codPedido) { 
		    if (!existePedido(codPedido)) {
		        throw new RuntimeException("Este Pedido No Existe");
		    }
		    Pedido pedidoActual = this.pedidosRegistrados.get(codPedido);
		    if (pedidoActual != null && !pedidoActual.isFinalizado()) {
		        return pedidoActual;
		    }

	        throw new RuntimeException("Este Pedido Ya Está Finalizado");
		}
			
	public boolean existePedido(int CodPedido) {
				return this.pedidosRegistrados.containsKey(CodPedido);
		}
		
		//el metodo quitarPaquete es de O(n cubo .k)
	public boolean quitarPaquete(int codPaquete) {	
			Pedido pedido = obtenerpedidoConUnPaquete(codPaquete);		// O(1)+(obtenerpedidoConUnPaquete tiene O(n.k))
			return pedido.eliminarPaqueteDelCarrito(codPaquete);		// O(N cuadrado)
			
		}
// Método auxiliar para obtener el pedido por código de paquete cuyo orden es O(n.k), con 'n' siendo el largo de pedidosRegistrados y 'k el largo del carrito del pedido
	public Pedido obtenerpedidoConUnPaquete(int codPaquete) {
			ArrayList<Pedido> pedidosTotales = new ArrayList<>(this.pedidosRegistrados.values());	
			for(Pedido pedidoActual: pedidosTotales) {			//O(n)
				for(Paquete PaqueteActual: pedidoActual.getCarrito()) {	//O(k)
					if (PaqueteActual.getIdentificador() == codPaquete) {	//O(1)
						return pedidoActual;
					}
				}
			}
			return null;
		}
		
	public double cerrarPedido(int codPedido) {			
		    if (!this.pedidosRegistrados.containsKey(codPedido) ) {
		        throw new RuntimeException("El pedido no existe ");
		    }
			
			Pedido pedido = obtenerPedido(codPedido);
			
			if (pedido == null || !(this.pedidosRegistrados.containsKey(pedido.getNumeroDePedido()))) {
			    throw new RuntimeException("El pedido no está en el sistema");
			}
			
		    // Verificar si el pedido es válido y no está finalizado
		    if (!(this.pedidosRegistrados.containsKey(pedido.getNumeroDePedido()))) {
		        throw new RuntimeException("El pedido No esta en el sistema");
		    }
  
		    if (pedido == null || pedido.isFinalizado()) {
		        throw new RuntimeException("El pedido no existe o ya está finalizado");
		    }
		    // Calcular el total a pagar
		    double totalAPagar = calcularTotalAPagar(pedido);

		    // Cambiar el estado del pedido a "finalizado"
		    pedido.cambiarFinalizado();
		    return totalAPagar;
		}

		private double calcularTotalAPagar(Pedido pedido) {
		    if (pedido == null || pedido.getCarrito() == null) {
		        return 0.0;
		    }

		    ArrayList<Paquete> carrito = pedido.getCarrito();
		    if (carrito == null) {
		        return 0.0;
		    }

		    double total = 0.0;
		    for (Paquete paquete : carrito) {
		        total += paquete.precioFinalDePaquete();
		    }		    
		   return total;
		}

	public double facturacionTotalPedidosCerrados() {
		double facturacionTotal = 0.0;
			// Recorre el mapa de pedidosRegistrados
		for (Pedido pedido : pedidosRegistrados.values()) {
				// Verifica si el pedido está cerrado
			if (pedido.isFinalizado()) {
					// Calcula el total a pagar y lo suma a la facturación total
				facturacionTotal += calcularTotalAPagar(pedido);
			}			}
			return facturacionTotal;
		}
	
    public boolean hayTransportesIdenticos() {
        List<Transporte> transportes = new ArrayList<>(flota.values());
        int tamañoCarga = transportes.size();
        for (int transpo = 0; transpo < tamañoCarga - 1; transpo++) {
            for (int transpo2 = transpo + 1; transpo2 < tamañoCarga; transpo2++) {
                Transporte transporte1 = transportes.get(transpo);
                Transporte transporte2 = transportes.get(transpo2);
                if (transporte1.getPaquetes().size() != 0 && transporte2.getPaquetes().size() != 0) { //ACA REVISO QUE NO COMPARE TRANSPORTES VAC�OS
                	if (transporte1.equals(transporte2)) {
                		
                		return true;  // Si encuentras un par de transportes idénticos, devolver verdadero y salir.
                	}
                }
            }
        }

        return false;  // Si no encuentras ningún par de transportes idénticos, devolver falso al final.
    }

  //metodo que se hace en O(1)  
    public double costoEntrega(String patente) {					
			if(!this.flota.containsKey(patente)||this.flota==null||this.flota.isEmpty()) {
				throw new RuntimeException("Transporte no esta en sistema");
			}
			
		    Transporte transporte = flota.get(patente);
		   
		    	if ( !transporte.getPaquetes().isEmpty()) {
		        	 return transporte.CalculaCostoDeViaje();
			        }
		    	else {
		        	 throw new RuntimeException("No se encontró el transporte o el transporte no tiene paquetes");

		     }
		   
	}

		public String cargarTransporte(String patente) {
	    // Comprobamos si la patente proporcionada está registrada en la flota.
	    if (!flota.containsKey(patente)) {
	        throw new RuntimeException("La patente no está registrada en el sistema.");
	    }
	    Transporte transporte = flota.get(patente);
	    StringBuilder carga = new StringBuilder();
	    for (Pedido pedido : pedidosRegistrados.values()) {
	    	
	        if (pedido.isFinalizado()) {
	            
	            for (Paquete paquete : pedido.getCarrito()) { 
	            	
	            	if(paquete.isEntregado()==false) {
	                   carga.append(" + [ ")
	                   .append(pedido.getNumeroDePedido())
	                   .append(" - ")
	                   .append(paquete.getIdentificador())
	                   .append(" ] ")
	                   .append(pedido.getCliente().getDireccion())
	                   .append("\n");   
	                   
	                   transporte.cargarPaquete(paquete);
	            		}
	            	}
	            pedido.cambiarEntregado();
	           	}
	        
	    }
	    if (carga.length() == 0) {
	        return "";
	    }
	    return carga.toString();
	}	
		
	public Map<Integer,String> pedidosNoEntregados(){
		
		Map<Integer, String> mapPedidosNoEntregados = new HashMap<>();
		
		for(Pedido pedidoNoEntregado : pedidosRegistrados.values()) {
			Cliente clienteActual =pedidoNoEntregado.getCliente();
			if(pedidoNoEntregado.isEntregado()&& pedidoNoEntregado.isFinalizado()) {	
				mapPedidosNoEntregados.put(pedidoNoEntregado.getNumeroDePedido(), clienteActual.getNombre());
				}
			}
		return mapPedidosNoEntregados;
	}

	@Override
	public String toString() {
		return "EmpresaAmazing [Cuil=" + Cuil + "\n flota=" + flota + "\n pedidosRegistrados=" + pedidosRegistrados + "]";
	}


	public Map<String, Transporte> getFlota() {
		return flota;
	}


	public void setFlota(Map<String, Transporte> flota) {
		this.flota = flota;
	}
	
	public String getCuil() {
		return Cuil;
	}

	public void setCuil(String cuil) {
		Cuil = cuil;
	}
	
	
}