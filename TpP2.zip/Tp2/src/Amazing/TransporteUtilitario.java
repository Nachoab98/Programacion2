package Amazing;
import java.util.ArrayList;

public class TransporteUtilitario extends Transporte{
	private ArrayList <Paquete> paquetesOrdYEsp;
	private double ValorExtra;
	
	public TransporteUtilitario(String patente, int volumenMaximoPorCarga, int costoPorViaje, int valorExtra) {
        super(patente, volumenMaximoPorCarga, costoPorViaje);			
        this.ValorExtra= valorExtra;
        this.paquetesOrdYEsp= new ArrayList<Paquete>();
    }
	public TransporteUtilitario() {
		
	}

    @Override
	public void cargarPaquete(Paquete paquete) {
		if (paquete==null) {
			throw new RuntimeException("Paquete es null");
			}
		if(this.getVolumenActual()+paquete.getVolumen()<this.getVolumenMaximoPorCarga() && (esEspecial(paquete)|| esOrdinario(paquete))) {
			
			if (!paqueteRepetido(paquete) ) {
				this.paquetesOrdYEsp.add(paquete);
				this.aumentarVolumen(paquete.getVolumen());
				paquete.setEntregado(true);
				}
		}	
	}
	@Override
	public double CalculaCostoDeViaje() {
		if (paquetesMayora3(this.paquetesOrdYEsp)) {
            return getCostoPorViaje() + this.ValorExtra;
        }
        return getCostoPorViaje();
	}
	
	//Metodo auxiliar de calculaCostoDeViaje
	public boolean paquetesMayora3(ArrayList<Paquete> paquetesDeUsuario) {	
		return (paquetesDeUsuario.size())>3;
	}
	
    //metodos auxiliares de cargarPaquete
    boolean esEspecial(Paquete paquete) {
		return (paquete instanceof PaqueteEspecial);
	}
	
	public boolean esOrdinario(Paquete paquete) {
		return (paquete instanceof PaqueteOrdinario);
	}

    @Override
    public ArrayList<Paquete> getPaquetes() {
		return paquetesOrdYEsp;
	}

	public void setPaquetesOrdYEsp(ArrayList<Paquete> paquetesOrdYEsp) {
		this.paquetesOrdYEsp = paquetesOrdYEsp;
	}

	public double getValorExtra() {
		return ValorExtra;
	}

	public void setValorExtra(double valorExtra) {
		ValorExtra = valorExtra;
	}

	@Override
	public String toString() {
		return "TransporteUtilitario [paquetesOrdYEsp=" + paquetesOrdYEsp + ", ValorExtra=" + ValorExtra + "]";
	}


	
	
}