package Amazing;

public abstract  class Paquete {
	private int Identificador;
	private static int contadorNumeroPaquete = 1;
	private int Volumen;
	private int Precio; 
	private boolean Entregado;

	public Paquete() {
			
		}
	
	public Paquete( int volumen, int precio) {
		super();
		Identificador = obtenerNumeroPaqueteUnico();
		Volumen = volumen;
		Precio = precio;
		Entregado = false;
	}
	
    public static int obtenerNumeroPaqueteUnico() {
        // Genera un número de paquete único utilizando el contador y lo incrementa
        int numeroPaquete = contadorNumeroPaquete;
        contadorNumeroPaquete++;
        return numeroPaquete;
    }
    

	public double costoDePaquete() {
		return this.Precio;
		
	}
	
	abstract public double precioFinalDePaquete();
	
	public int getIdentificador() {
		return Identificador;
	}

	public void setIdentificador(int identificador) {
		Identificador = identificador;
	}

	public int getVolumen() {
		return Volumen;
	}

	public void setVolumen(int volumen) {
		Volumen = volumen;
	}

	public int getPrecio() {
		return Precio;
	}

	public void setPrecio(int precio) {
		Precio = precio;
	}

	public boolean isEntregado() {
		return Entregado;
	}

	public void setEntregado(boolean entregado) {
		Entregado = entregado;
	}

	@Override
	public String toString() {
		return "Paquete [Identificador=" + Identificador + ", Volumen=" + Volumen + ", Precio=" + Precio
				+ ", Entregado=" + Entregado + "]";
	}
	
	public abstract boolean equals(Paquete paquete);
}