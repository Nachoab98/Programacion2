package Amazing;

public class PaqueteEspecial extends Paquete{
	private int Porcentaje;
	private int Adicional;
	
	public PaqueteEspecial( int volumen, int precio , int porcentaje, int adicional) {
		super(volumen, precio);	
		this.Porcentaje= porcentaje;
		this.Adicional= adicional;
		
	}
	public PaqueteEspecial() {
		
	}
	@Override
	public boolean equals(Paquete paquete) {
		boolean acum=true;
		if(paquete instanceof PaqueteEspecial) {
			PaqueteEspecial paqueteEsp =(PaqueteEspecial) paquete;
				acum=acum && this.getVolumen()==paqueteEsp.getVolumen() && 
					this.getPrecio()==paqueteEsp.getPrecio()&&
					this.getPorcentaje()==paqueteEsp.getPorcentaje()&&
					this.getAdicional()==paqueteEsp.getAdicional();
		}
		else {
			return false;
		}
    	return acum;
    }
	
	public int calcularPorcentaje() {
		return  ((this.getPrecio() * this.Porcentaje) / 100);
	}
	
	public int calcularPrecioFinal() {		
		if(Consultarvolumen3000()) {
			return calcularPorcentaje()+this.getPrecio()+this.Adicional;
		}
		if(Consultarvolumen5000()) {
			return calcularPorcentaje()+this.getPrecio()+this.Adicional+this.Adicional;
		}
		return this.getPrecio()+calcularPorcentaje();
	}
	
	//metodos auxiliares de calcuarPrecioFinal
	public boolean Consultarvolumen3000() {
		if (this.getVolumen()>=3000 && this.getVolumen()<5000) {
			return true;
		}
		return false;
	}
	
	public boolean Consultarvolumen5000() {
		if (this.getVolumen()>=5000 ) {
			return true;
		}
		return false;
	}
	
	@Override
	public double precioFinalDePaquete() {
		return calcularPrecioFinal();
		}
	
	
	public int getPorcentaje() {
		return Porcentaje;
	}
	public void setPorcentaje(int porcentaje) {
		Porcentaje = porcentaje;
	}
	public int getAdicional() {
		return Adicional;
	}
	public void setAdicional(int adicional) {
		Adicional = adicional;
	}
		
	
	@Override
	public String toString() {
		return "PaqueteEspecial [Identificador=" + getIdentificador() + ", Volumen=" + getVolumen() + ", Precio=" + getPrecio()
				 + ", Porcentaje=" +this.Porcentaje+", Adicional="+this.Adicional + ", Entregado=" + isEntregado() + "]";
	}



		
		
	
}
