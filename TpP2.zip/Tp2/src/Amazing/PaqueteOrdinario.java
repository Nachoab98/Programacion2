package Amazing;

public class PaqueteOrdinario extends Paquete{
	private int CostoEnvio;
	
	public PaqueteOrdinario( int volumen, int precio, int costoEnvio) {
		//nose si aumenta el id 
			super(volumen,precio);			
			this.CostoEnvio=costoEnvio;
			
    	}
	
	@Override
	public double precioFinalDePaquete() {
		return this.getPrecio()+this.getCostoEnvio();
		
	}

	
	public int getCostoEnvio() {
		return CostoEnvio;
	}

	public void setCostoEnvio(int costoEnvio) {
		CostoEnvio = costoEnvio;
	}
	
	
	@Override
	public String toString() {
		return "PaqueteOrdinario [Identificador=" + getIdentificador() + ", Volumen=" + getVolumen() + ", Precio=" + getPrecio()
				 +"CostoEnvio= "+getCostoEnvio()+", Entregado=" + isEntregado() + "]";
	}
	

	public boolean equals(Paquete paquete) {
		boolean acum=true;
		if(paquete instanceof PaqueteOrdinario) {
			PaqueteOrdinario paqueteOrd =(PaqueteOrdinario) paquete;
				acum=acum && this.getVolumen()==paqueteOrd.getVolumen() && 
						this.getPrecio()==paqueteOrd.getPrecio();
		}
		else {
			return false;
		}
    	return acum; 
    	}

}