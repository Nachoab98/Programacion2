package Amazing;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public abstract class Transporte {
	private String Patente;
	private int VolumenMaximoPorCarga;
	private double CostoPorViaje;
	private ArrayList<Paquete> paquetes;
	private int VolumenActual;

	
	public Transporte() {}

	public Transporte(String patente, int volumenMaximoPorCarga, int costoPorViaje) {
		Patente = patente;
		VolumenMaximoPorCarga = volumenMaximoPorCarga;
		CostoPorViaje = costoPorViaje;
		this.paquetes = new ArrayList<Paquete>();
		VolumenActual=0;
	}
	//EQUALS
	public boolean equals(Transporte transporte2) {
        return this.mismaCarga(transporte2) && !this.patentesIguales(transporte2.getPatente()) &&
               this.mismoTipoDeTransporte(transporte2);     
        
    }
//auxiliares de equals
	public boolean mismaCarga(Transporte transporte1) {
		    Set<Paquete> carga1 = new HashSet<>(transporte1.getPaquetes());
		    
		    if (carga1.size() != this.getPaquetes().size()) {
		        return false;
		    }
		    for (Paquete paquete : carga1) {
		        boolean encontrado = false;
		        for (Paquete paquete2 : this.getPaquetes()) {
		            if (paquete instanceof PaqueteOrdinario && paquete2 instanceof PaqueteOrdinario) {
		            	if(paquete.equals(paquete)){
		                encontrado = true;
		                break;
		            }
		            	}
		            if (paquete instanceof PaqueteEspecial && paquete2 instanceof PaqueteEspecial) {
		            	if(paquete.equals(paquete)){
			                encontrado = true;
			                break;
			            }
		            }
		        }
		        if (!encontrado) {
		            return false;
		        }
		    }
		    return true;
		}
	
	public boolean patentesIguales(String patente1) {
        return this.Patente.equals(patente1);
    }
	
	public boolean mismoTipoDeTransporte(Transporte transporte1) {
	    return this.getClass().isInstance(transporte1);
	}
// hasta aca auxiliares de equals
	
	public boolean paqueteRepetido(Paquete paquete) {
		return paquetes.contains(paquete);
	}
	
	abstract public void cargarPaquete(Paquete paquete) ;	

	abstract public double CalculaCostoDeViaje(); 
	
	public void aumentarVolumen(int volumenDePaquete) {
		this.VolumenActual = this.VolumenActual + volumenDePaquete;
	}
	
	ArrayList<Paquete> PaqueteCargados(){
	        return paquetes;
	}
	
	public String getPatente() {
		return Patente;
	}



	public void setPatente(String patente) {
		Patente = patente;
	}



	public int getVolumenMaximoPorCarga() {
		return VolumenMaximoPorCarga;
	}



	public void setVolumenMaximoPorCarga(int volumenMaximoPorCarga) {
		VolumenMaximoPorCarga = volumenMaximoPorCarga;
	}



	public double getCostoPorViaje() {
		return CostoPorViaje;
	}



	public void setCostoPorViaje(int costoPorViaje) {
		CostoPorViaje = costoPorViaje;
	}

	
	
	public ArrayList<Paquete> getPaquetes() {
		return paquetes;
	}



	public void setPaquetes(ArrayList<Paquete> paquetes) {
		this.paquetes = paquetes;
	}

	public int getVolumenActual() {
		return VolumenActual;
	}

	public void setVolumenActual(int volumenActual) {
		VolumenActual = volumenActual;
	}

	public void setCostoPorViaje(double costoPorViaje) {
		CostoPorViaje = costoPorViaje;
	}

	

}
