package Amazing;

import java.util.ArrayList;


public class Pedido {
	private int NumeroDePedido;
	private static int contadorNumeroPedido = 1; // Variable estática para que todas las intancias compartan el mismo contador
	private Cliente cliente;
	private boolean Finalizado;//consultar si estado va a ser finalizafdo  
	private boolean Entregado;
	private ArrayList<Paquete> Carrito;

	public Pedido () {	
		
	}
	
	
	public Pedido(Cliente cliente) {
		NumeroDePedido = obtenerNumeroPedidoUnico();//con esto se soluciona lo de los id unicos
		this.cliente = cliente;
		Finalizado = false;
		Entregado=false;
		Carrito=  new ArrayList <Paquete>();;
	}
	
	public int agregarPaqueteEsp(int codPedido, int volumen, int precio, int porcentaje, int adicional) {

		Paquete nuevoPaqueteEsp= new PaqueteEspecial(volumen, precio, porcentaje, adicional);
	
		if(this.getCarrito()!=null && nuevoPaqueteEsp!=null) {
			this.agregarProductoAlCarrito(nuevoPaqueteEsp);
			return	nuevoPaqueteEsp.getIdentificador();	
		}
		throw new RuntimeException("no se puede agregar el paquete");	
	}
	
	public int agregarPaqueteOrd(int codPedido, int volumen, int precio, int costoEnvio) {

		Paquete nuevoPaqueteOrd= new PaqueteOrdinario(volumen, precio, costoEnvio);
	
		if(this.getCarrito()!=null && nuevoPaqueteOrd!=null) {
				this.agregarProductoAlCarrito(nuevoPaqueteOrd);
				return	nuevoPaqueteOrd.getIdentificador();	
			}
			throw new RuntimeException("no se puede agregar el paquete");
			
		}

	public boolean yaEstaEnCarrito(Paquete producto) {
		return this.Carrito.contains(producto);
	}
	
	public void agregarProductoAlCarrito(Paquete paquete) {
		if(!yaEstaEnCarrito(paquete)) {
				this.Carrito.add(paquete);
			}
	}
	// la complejidad es O(N al cuadrado)
	public boolean eliminarPaqueteDelCarrito(int codPaquete) {
	    Paquete paquete = obtenerPaquetePorCodigo(codPaquete);		//O(N) + O(1)  
	    if (paquete != null) {										//O(1)			
	        return this.Carrito.remove(paquete);					//O(N)
	    }
	    return false;
	}
	//metodo auxilliar de eliminarPaquete
	private Paquete obtenerPaquetePorCodigo(int codPaquete) {
	    for (Paquete paquete : this.Carrito) {		 	//O(N)
	        if (paquete.getIdentificador() == codPaquete) {		// O(1)	
	            return paquete; // Se encontró el paquete		O(1)
	        }
	    }
	    return null; 
	}
	
	
	public boolean tienePaquete(int codigoPaquete) {
		Paquete paquete = obtenerPaquetePorCodigo(codigoPaquete);
		if (paquete==null) {
		
			return false;
		}
			
		return true; 
	}
	public void cambiarEntregado() {
		this.setEntregado(true);
	}
				
	//auxiliar del para que el numero de pedido sea unico 
	
	
	//getters y setters
    private static int obtenerNumeroPedidoUnico() {
        // Genera un número de pedido único utilizando el contador y lo incrementa
        int numeroPedido = contadorNumeroPedido;
        contadorNumeroPedido++;
        return numeroPedido;
    }
    

	
	public int costoEnvioDePaquetes() {
		int costo = 0;
		for (Paquete paqueteActual : this.Carrito) {
			costo = costo + paqueteActual.getPrecio();
		}
		return costo;
	}
	public double totalAPagar() {
	    double total = 0.0;
	    for (Paquete paquete : this.Carrito) {
	        total += paquete.precioFinalDePaquete();
	    }	
	    return total;
	}

	public void cambiarFinalizado() {
		this.setFinalizado(true);
	}

	public int getNumeroDePedido() {
		return NumeroDePedido;
	}


	public void setNumeroDePedido(int numeroDePedido) {
		NumeroDePedido = numeroDePedido;
	}


	public Cliente getCliente() {
		return cliente;
	}


	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}


	public boolean isFinalizado() {
		return Finalizado;
	}


	public void setFinalizado(boolean finalizado) {
		Finalizado = finalizado;
	}


	public boolean isEntregado() {
		return Entregado;
	}


	public void setEntregado(boolean entregado) {
		Entregado = entregado;
	}


	public ArrayList<Paquete> getCarrito() {
		return Carrito;
	}


	public void setCarrito(ArrayList<Paquete> carrito) {
		Carrito = carrito;
	}
	//ToString
	@Override
	public String toString() {
		return "Pedido [NumeroDePedido=" + NumeroDePedido + ", cliente=" + cliente + ", Finalizado=" + Finalizado
				+ ", Entregado=" + Entregado + ", Carrito=" + Carrito + "]";
	}
	
	
}
