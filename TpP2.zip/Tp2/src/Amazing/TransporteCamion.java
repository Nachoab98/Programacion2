package Amazing;

import java.util.ArrayList;

public class TransporteCamion extends Transporte {
    private ArrayList<Paquete> PaquetesEspeciales;
    private double ValorExtra;
   

    public TransporteCamion(String patente, int volumenMaximoPorCarga, int costoPorViaje, int valorExtra) {
        super(patente, volumenMaximoPorCarga, costoPorViaje);
        this.ValorExtra = valorExtra;
        this.PaquetesEspeciales = new ArrayList<Paquete>();
        this.getVolumenActual();
    }
    
	
	public TransporteCamion() {
		
	}


	boolean esEspecial(Paquete paquete) {
		return (paquete instanceof PaqueteEspecial);
	}
	
	@Override
	public void cargarPaquete(Paquete paquete) {
		if (paquete==null) {
			throw new RuntimeException("Paquete es null");
			}
		if(this.getVolumenActual()+paquete.getVolumen()<this.getVolumenMaximoPorCarga()) {
			if (!paqueteRepetido(paquete) && esEspecial(paquete) && (paquete.getVolumen() >2000) ){
				this.PaquetesEspeciales.add(paquete);
				this.aumentarVolumen(paquete.getVolumen());
				paquete.setEntregado(true);
				}
			}
		}
@Override
    public double CalculaCostoDeViaje() {
    	return (PaquetesEspeciales.size())*this.ValorExtra+getCostoPorViaje();
    }
    
 @Override
    public ArrayList<Paquete> getPaquetes() {
		return PaquetesEspeciales;
	}

	public void setPaquetesEspeciales(ArrayList<Paquete> paquetesEspeciales) {
		PaquetesEspeciales = paquetesEspeciales;
	}

	public double getValorExtra() {
		return ValorExtra;
	}

	public void setValorExtra(double valorExtra) {
		ValorExtra = valorExtra;
	}

	@Override
	public String toString() {
		return "TransporteCamion [PaquetesEspeciales=" + PaquetesEspeciales + ", ValorExtra=" + ValorExtra + "]";
	}


	
	
}
