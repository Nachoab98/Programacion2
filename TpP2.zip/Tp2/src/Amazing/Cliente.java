package Amazing;

//import java.util.ArrayList;

public class Cliente {
	private String Nombre;
	private String Direccion;
	private int DNI;

	public Cliente(String nombre, String direccion, int dni) {
		this.Nombre = nombre;
		this.Direccion = direccion;
		this.DNI = dni;
	}

	
	public String getNombre() {
		return Nombre;
	}


	public void setNombre(String nombre) {
		Nombre = nombre;
	}


	public String getDireccion() {
		return Direccion;
	}


	public void setDireccion(String direccion) {
		Direccion = direccion;
	}


	public int getDNI() {
		return DNI;
	}


	public void setDNI(int dNI) {
		DNI = dNI;
	}


	@Override
	public String toString() {
		return "Cliente [Nombre=" + Nombre + ", Direccion=" + Direccion + ", DNI=" + DNI + "]";
	}
	
	

}
