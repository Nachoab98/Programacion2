package Amazing;

import java.util.ArrayList;

public class TransporteComun extends Transporte {
	private ArrayList <Paquete> paquetesOrdinarios;
	private int MaxPaquetes;
	
	public TransporteComun(String patente, int volumenMaximoPorCarga, int costoPorViaje, int maxPaquetes) {
        super(patente, volumenMaximoPorCarga, costoPorViaje);			
        this.paquetesOrdinarios= new ArrayList<Paquete>();
        this.MaxPaquetes= maxPaquetes;
    }
	
	public TransporteComun() {
		
	}
	
	@Override
	public void cargarPaquete(Paquete paquete) {
		if (paquete==null) {
			throw new RuntimeException("Paquete es null");
			}

		if(this.getVolumenActual()+paquete.getVolumen()<this.getVolumenMaximoPorCarga()||paquetesOrdinarios.size()>MaxPaquetes) {
		
			if (!paqueteRepetido(paquete) && esOrdinario(paquete) && (paquete.getVolumen() <= 2000) ){
				this.paquetesOrdinarios.add(paquete);
				this.aumentarVolumen(paquete.getVolumen());
				paquete.setEntregado(true);
			}
		}
	}
	
	public boolean esOrdinario(Paquete paquete) {
		return (paquete instanceof PaqueteOrdinario);
	}
	
	
	public double CalculaCostoDeViaje() {
		
		return this.getCostoPorViaje();
	}
	
	
	@Override
    public ArrayList<Paquete> getPaquetes() {
		return paquetesOrdinarios;
	}

	public void setPaquetesOrdinarios(ArrayList<Paquete> paquetesOrdinarios) {
		this.paquetesOrdinarios = paquetesOrdinarios;
	}

	@Override
	public String toString() {
		return "TransporteComun [paquetesOrdinarios=" + paquetesOrdinarios + "]";
	}

	public boolean equals(TransporteComun transporte) {
		return this.getPatente() != transporte.getPatente() ;
	}

	
	
}